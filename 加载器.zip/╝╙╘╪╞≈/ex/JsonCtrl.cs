﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 加载器.ex
{
    class JsonCtrl
    {
        private Dictionary<string, string> dt_10 = new Dictionary<string, string>();
        private Dictionary<string, List<string>> dt_11 = new Dictionary<string, List<string>>();
        private Dictionary<string, bool> dt_20 = new Dictionary<string, bool>();
        private Dictionary<string, List<bool>> dt_21 = new Dictionary<string, List<bool>>();
        private Dictionary<string, int> dt_30 = new Dictionary<string, int>();
        private Dictionary<string, List<int>> dt_31 = new Dictionary<string, List<int>>();
        private Dictionary<string, Dictionary<string, string>> dt_40 = 
            new Dictionary<string, Dictionary<string, string>>();

        public JsonCtrl()
        {
        }
    }
}
