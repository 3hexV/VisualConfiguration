﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace 加载器
{
    class IniCtrl
    {
        //ini文件的路径名称
        public string inipath;

        // 声明INI文件的写操作函数 WritePrivateProfileString()
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        // 声明INI文件的读操作函数 GetPrivateProfileString()
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        //string section:配置文件的section名，在ini文件中显示例如：[MagTask]
        //string key:配置文件的section名，在ini文件中显示例如：OrderID=8450
        //string def:如果INI文件中没有前两个参数指定的字段名或键名,则将此值赋给变量 
        //StringBuilder retVal:接收INI文件中的值的CString对象,即目的缓存器. 例如：StringBuilder temp = new StringBuilder(500);
        //int size:目的缓存器的大小.例如：500
        //string filePath:是完整的INI文件名. 
        //容易出错：例如将Server.ini放在应用程序相同的目录下，此处填写"Server.ini"结果读不出来==>解决  改为".\\server.ini" 

        /// <summary>
        /// 构造方法
        /// </summary>
        /// <param name="INIPath">文件路径</param>
        public IniCtrl(string INIPath)
        {
            inipath = INIPath;
        }

        /// <summary>
        /// 写入INI文件
        /// </summary>
        /// <param name="Section">项目名称(如 [TypeName] )</param>
        /// <param name="Key">键</param>
        /// <param name="Value">值</param>
        public void IniWriteValue(string Section, string Key, string Value)
        {
            WritePrivateProfileString(Section, Key, Value, this.inipath);
        }

        /// <summary>
        /// 读出INI文件
        /// </summary>
        /// <param name="Section">项目名称(如 [TypeName] )</param>
        /// <param name="Key">键</param>
        public string IniReadValue(string Section, string Key)
        {
            StringBuilder temp = new StringBuilder(500);
            int i = GetPrivateProfileString(Section, Key, "", temp, 500, this.inipath);
            return temp.ToString();
        }

        /// <summary>
        /// 验证文件是否存在
        /// </summary>
        /// <returns>布尔值</returns>
        public bool ExistINIFile()
        {
            return File.Exists(inipath);
        }
    }
}
