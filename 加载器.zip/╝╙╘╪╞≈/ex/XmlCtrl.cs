﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml;

namespace XmlCtrlSpace
{
    class XmlCtrl
    {
        public XmlDocument doc = new XmlDocument();
        public string fileurl;
        public XmlNode nodeRoot = null;

        public XmlCtrl(string str_fileurl)
        {
            this.fileurl = str_fileurl;
            this.LoadXml(this.fileurl);
            this.nodeRoot = this.GetXmlDocumentRoot();
        }

        public XmlCtrl()
        {
        }

        //文件路径
        public string FileUrl
        {
            set { fileurl = value; }
            get { return fileurl; }
        }

        /// <summary>
        /// 工具方法：字符串列表转为字符串
        /// </summary>
        /// <param name="list_str"></param>
        /// <param name="div"></param>
        /// <returns></returns>
        public string List_StrToStr(List<string> list_str, string div="")
        {
            return string.Join(div, list_str);
        }

        /// <summary>
        /// 工具方法：字符串列表的列表 通过下标对齐 转为字符串
        /// </summary>
        /// <param name="list_str"></param>
        /// <param name="div"></param>
        /// <returns></returns>
        public string List_StrToStr(List<List<string>> list_str, string div = "")
        {
            string str_res = "";
            for (int i = 0; i < list_str[0].Count; i++)
            {
                for (int j = 0; j < list_str.Count; j++)
                {
                    str_res += list_str[j][i] + "   ";
                }
                str_res += "\n";
            }
            return str_res;
        }

        /// <summary>
        /// 系统方法：载入Xml文件
        /// </summary>
        /// <param name="url">Xml文件路径</param>
        public void LoadXml(string url)
        {
            doc.Load(url);
        }

        /// <summary>
        /// 读取方法：获取根节点
        /// </summary>
        /// <returns>根节点</returns>
        public XmlNode GetXmlDocumentRoot()
        {
            return doc.DocumentElement;
        }

        /// <summary>
        /// 读取方法：获取一个节点的一个子节点
        /// </summary>
        /// <param name="xn">节点</param>
        /// <param name="node_name">节点名称</param>
        /// <returns>XmlNode</returns>
        public XmlNode GetSingleChildNodeByName(XmlNode xn, string node_name)
        {
            return xn.SelectSingleNode(node_name);
        }

        /// <summary>
        /// 读取方法：获取一个节点的所有子节点
        /// </summary>
        /// <param name="xn">节点</param>
        /// <param name="node_name">节点名称</param>
        /// <returns>XmlNodeList</returns>
        public XmlNodeList GetAllChildNodeByName(XmlNode xn, string node_name)
        {
            return xn.SelectNodes(node_name);
        }

        /// <summary>
        /// 读取方法：获取一个节点的文本
        /// </summary>
        /// <param name="xn">节点</param>
        /// <returns></returns>
        public string GetRawTextByNode(XmlNode xn)
        {
            return xn.InnerText;
        }

        /// <summary>
        /// 读取方法：获取一个节点的文本（文本通过split分割处理过）
        /// </summary>
        /// <param name="xn">节点</param>
        /// <param name="div">分割字符</param>
        /// <returns></returns>
        public string[] GetHandledTextByNodeUseSplit(XmlNode xn, char div)
        {
            return xn.InnerText.Split(div);
        }

        /// <summary>
        /// 读取方法：返回该节点的孩子数量
        /// </summary>
        /// <param name="xn">节点</param>
        /// <returns></returns>
        public uint GetNodeChildCount(XmlNode xn)
        {
            return (uint)xn.ChildNodes.Count;
        }

        /// <summary>
        /// 读取方法：获取该节点的所有属性名
        /// </summary>
        /// <param name="xn"></param>
        /// <returns></returns>
        public List<string> GetNodeAllAtt_Name(XmlNode xn)
        {
            List<string> list_res = new List<string>();
            XmlElement xe = (XmlElement)xn;
            if (xe.Attributes.Count > 0)
            {
                foreach (XmlNode attr in xe.Attributes)
                {
                    list_res.Add(attr.Name);
                }
                return list_res;
            }
            list_res.Add("");
            return list_res;
        }

        /// <summary>
        /// 读取方法：获取节点的所有属性和值
        /// </summary>
        /// <param name="xn"></param>
        /// <returns></returns>
        public List<List<string>> GetNodeAllAtt_NameAndValue(XmlNode xn)
        {
            List<List<string>> list_res = new List<List<string>>();
            List<string> list_name = new List<string>();
            List<string> list_value = new List<string>();
            XmlElement xe = (XmlElement)xn;
            if (xe.Attributes.Count > 0)
            {
                foreach (XmlNode attr in xe.Attributes)
                {
                    list_name.Add(attr.Name);
                    list_value.Add(attr.Value);
                }
                list_res.Add(list_name);
                list_res.Add(list_value);
                return list_res;
            }
            return list_res;
        }

        /// <summary>
        /// 读取方法：返回一个节点个某个属性的值
        /// </summary>
        /// <param name="xn">节点</param>
        /// <param name="att_name">属性名</param>
        /// <returns></returns>
        public string GetNodeAttByAtt_Name(XmlNode xn, string att_name)
        {
            XmlElement xe = (XmlElement)xn;
            return xe.GetAttribute(att_name);
        }

        /// <summary>
        /// 返回具有某个属性的某个属性值的元素节点
        /// </summary>
        /// <param name="att_name"></param>
        /// <param name="att_value"></param>
        /// <returns></returns>
        public XmlElement GetNodeByPosAttAndValue(string att_name, string att_value)
        {
            foreach (XmlNode row in this.nodeRoot.ChildNodes)
            {
                foreach (XmlElement xe in row.ChildNodes)
                {
                    if (xe.GetAttribute(att_name) == att_value)
                    {
                        return xe;
                    }    
                }
            }
            return (XmlElement)this.nodeRoot;
        }

        /// <summary>
        /// 写入方法：更新一个节点的属性值(属性不存在，不添加）
        /// </summary>
        /// <param name="xn">节点</param>
        /// <param name="att_name">属性名</param>
        /// <param name="att_value">属性值</param>
        public short UpdateNodeAttValue(XmlNode xn, string att_name, string att_value)
        {
            XmlElement xe = (XmlElement)xn;
            if (xe.HasAttribute(att_name) == true)
            {
                xe.SetAttribute(att_name, att_value);
                SaveXml();
                return 0;
            }
            else
            {
                return -1;
            }
        }

        /// <summary>
        /// 系统方法：保存XML文件
        /// </summary>
        public void SaveXml()
        {
            this.doc.Save(this.fileurl);
        }

    }
}
