﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace 加载器
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
        }

        private void bt_open_file_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "选择XML文件";
            openFileDialog.Filter = "xml|*.xml";
            openFileDialog.FileName = string.Empty;
            openFileDialog.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            
            if (openFileDialog.ShowDialog() == true)
            {
                // 将路径显示在文本框中
                this.tb_tx.Text = openFileDialog.FileName;
                //MessageBox.Show(openFileDialog.FileName);
                // 打开配置界面
                ShowConfigWin(openFileDialog.FileName);
            }
            else {
                MessageBox.Show("没有选中相应的XML文件");
            }
        }

        // 对url指定的XML文件进行读取
        private void ShowConfigWin(string file_url)
        {
            ConfigShow win_cs = new ConfigShow(file_url);
            win_cs.Show();
            this.Close();
        }

        private void menu_item_ver_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("V1.0.1\n持续完善中...\n\t\t:)");
        }

        private void menu_item_abut_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("作者：3hex\n联系：kvv3hex@gmail.com");
        }
    }

}
