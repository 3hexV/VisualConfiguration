﻿namespace 加载器
{
    internal class FolderBrowserDialog
    {
    }
}