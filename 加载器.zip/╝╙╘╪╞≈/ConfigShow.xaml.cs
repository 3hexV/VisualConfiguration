﻿using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Linq;
using XmlCtrlSpace;

namespace 加载器
{
    /// <summary>
    /// ConfigShow.xaml 的交互逻辑
    /// </summary>
    public partial class ConfigShow : Window
    {
        private string fileUrl = "";
        private XmlCtrl xc = null;
        // 控件控制面板
        private CtrlPlant cpt = new CtrlPlant();

        public ConfigShow(string file_url)
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            this.fileUrl = file_url;
            LoadConfigByXml(this.fileUrl);
        }

        private void LoadConfigByXml(string fileurl)
        {
            this.xc = new XmlCtrl(fileurl);
            this.cpt.Xc = this.xc;
            this.cpt.Stackpanel_main = this.stackpanel_main;
        }

        private void Window_SetWinAtt(XmlCtrl xc)
        {
            win_config.Title = xc.GetNodeAttByAtt_Name(xc.nodeRoot, "title");
            win_config.Height = Convert.ToDouble(xc.GetNodeAttByAtt_Name(xc.nodeRoot, "height"));
            win_config.Width = Convert.ToDouble(xc.GetNodeAttByAtt_Name(xc.nodeRoot, "widht"));
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Window_SetWinAtt(xc);

            foreach (XmlNode xn_row in xc.GetAllChildNodeByName(xc.nodeRoot, "row"))
            {
                foreach (XmlNode xn in xn_row.ChildNodes)
                {
                    XmlElement xe = (XmlElement)xn;
                    switch (xe.Name)
                    {
                        case "text":
                            this.cpt.Add_Text(xe.GetAttribute("label_name"),
                                xe.GetAttribute("key"));
                            break;
                        case "checkbox":
                            this.cpt.Add_CheckBox(xe.GetAttribute("label_name"), xe.InnerText,
                                xe.GetAttribute("key"));
                            break;
                        case "radio":
                            this.cpt.Add_Radio(xe.GetAttribute("label_name"), xe.InnerText,
                                xe.GetAttribute("key"));
                            break;
                        case "select":
                            this.cpt.Add_Select(xe.GetAttribute("label_name"), xe.InnerText,
                                xe.GetAttribute("key"));
                            break;
                    }
                }
                this.cpt.Add_DivLine();
            }
            this.cpt.Add_DefButtont();
        }

    }

    /// <summary>
    /// 控件控制面板
    /// </summary>
    class CtrlPlant
    {
        private StackPanel stackpanel_main = new StackPanel();
        public List<string> ctrl_xname = new List<string>();
        private XmlCtrl xc = new XmlCtrl();
        private string save_func = "";

        public StackPanel Stackpanel_main { get => stackpanel_main; set => stackpanel_main = value; }
        internal XmlCtrl Xc { get => xc; set => xc = value; }

        public CtrlPlant(StackPanel stackpanel_main, XmlCtrl xc_temp)
        {
            this.Stackpanel_main = stackpanel_main;
            this.Xc = xc_temp;
        }

        public CtrlPlant()
        { }

        /// <summary>
        /// 添加默认按钮
        /// </summary>
        public void Add_DefButtont()
        {
            List<string> all_save_func = new List<string>();
            all_save_func.Add("json");
            all_save_func.Add("xml");
            all_save_func.Add("csv");
            all_save_func.Add("ini");

            Button btn_ok = new Button();
            Button btn_clear = new Button();
            StackPanel sp_new = new StackPanel();
            ComboBox cbx_save = new ComboBox();

            foreach (string str in all_save_func)
            {
                cbx_save.Items.Add(str);
            }

            cbx_save.Name = "cbx_save";
            stackpanel_main.RegisterName(cbx_save.Name, cbx_save);

            cbx_save.SelectedIndex = 0;
            cbx_save.Width = 100;

            sp_new.Orientation = Orientation.Horizontal;
            sp_new.Margin = new Thickness(0, 15, 15, 25);

            btn_ok.Width = 50;
            btn_clear.Width = 50;
            btn_clear.Margin = new Thickness(15, 0, 15, 0);

            btn_ok.Content = "保存";
            btn_clear.Content = "清空";

            sp_new.HorizontalAlignment = HorizontalAlignment.Right;
            sp_new.VerticalAlignment = VerticalAlignment.Bottom;

            btn_ok.Click += new RoutedEventHandler(btn_ok_click);
            btn_clear.Click += new RoutedEventHandler(btn_clear_click);

            sp_new.Children.Add(cbx_save);
            sp_new.Children.Add(btn_clear);
            sp_new.Children.Add(btn_ok);
            stackpanel_main.Children.Add(sp_new);
        }

        /// <summary>
        /// 清空按钮事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_clear_click(object sender, RoutedEventArgs e)
        {


            foreach (string ctrl_item in this.ctrl_xname)
            {
                switch (ctrl_item.Replace("__", "|").Split('|')[0])
                {
                    case "tb":
                        TextBox bt = stackpanel_main.FindName(ctrl_item) as TextBox;
                        bt.Text = "";
                        break;
                    case "lib_checkbox":
                        WrapPanel wp = stackpanel_main.FindName(ctrl_item) as WrapPanel;
                        foreach (CheckBox cb in wp.Children)
                        {
                            cb.IsChecked = false;
                        }
                        break;
                    case "lib_radiobutton":
                        bool first_select_temp = false;
                        WrapPanel wp2 = stackpanel_main.FindName(ctrl_item) as WrapPanel;
                        foreach (RadioButton rb in wp2.Children)
                        {
                            if (first_select_temp == false)
                            {
                                rb.IsChecked = true;
                                first_select_temp = true;
                            }
                            else
                            {
                                rb.IsChecked = false;
                            }
                        }
                        break;
                    case "cbx":
                        ComboBox cbx = stackpanel_main.FindName(ctrl_item) as ComboBox;
                        cbx.SelectedIndex = 0;
                        break;
                }
            }
        }

        /// <summary>
        /// 保存按钮事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_ok_click(object sender, RoutedEventArgs e)
        {
            ComboBox cb = stackpanel_main.FindName("cbx_save") as ComboBox;
            this.save_func = cb.SelectedItem.ToString();

            List<List<string>> data = GetAllDataBeforeSave();
            if (data == null)
            {
                MessageBox.Show("有属性为空，不能保存！");
                return;
            }

            // json_1格式
            Dictionary<string, object> dict_data = new Dictionary<string, object>();
            foreach (List<string> ls in data)
            {
                if (ls.Count == 2)
                {
                    string raw_data = ls[1];
                    if (raw_data == "true")
                    {
                        dict_data[ls[0]] = true;
                    }
                    else if (raw_data == "false")
                    {
                        dict_data[ls[0]] = false;
                    }
                    else if (isDouble(ls[1]) == true)
                    {
                        dict_data[ls[0]] = Convert.ToDouble(ls[1]);
                    }
                    else if (isNumberic(ls[1]) == true)
                    {
                        dict_data[ls[0]] = Convert.ToInt32(ls[1]);
                    }
                    else {
                        dict_data[ls[0]] = ls[1];
                    }
                }
                else if (ls.Count != 0 && ls.Count > 2)
                {
                    string key = ls[0];
                    string raw_data = ls[1];
                    
                    if (raw_data == "true")
                    {
                        List<object> t_list = new List<object>();
                        ls.RemoveAt(0);
                        ls.ForEach(i => t_list.Add(strToBool(i)));
                        dict_data[key] = t_list;
                    }
                    else if (raw_data == "false")
                    {
                        List<object> t_list = new List<object>();
                        ls.RemoveAt(0);
                        ls.ForEach(i => t_list.Add(strToBool(i)));
                        dict_data[key] = t_list;
                    }
                    else if (isDouble(ls[1]) == true)
                    {
                        List<object> t_list = new List<object>();
                        ls.RemoveAt(0);
                        ls.ForEach(i => t_list.Add(Convert.ToDouble(i)));
                        dict_data[key] = t_list;
                    }
                    else if (isNumberic(ls[1]) == true)
                    {
                        List<object> t_list = new List<object>();
                        ls.RemoveAt(0);
                        ls.ForEach(i => t_list.Add(Convert.ToInt32(i)));
                        dict_data[key] = t_list;
                    }
                    else
                    {
                        List<object> t_list = new List<object>();
                        ls.ForEach(i => t_list.Add(i));
                        t_list.RemoveAt(0);
                        dict_data[key] = t_list;
                    }
                }
            }

            // json_2格式
            Dictionary<string, object> dict_data_2 = new Dictionary<string, object>();
            foreach (XmlNode xn in this.xc.GetAllChildNodeByName(this.xc.nodeRoot,"row"))
            {
                XmlElement xe = (XmlElement)xn;
                string selection = xe.GetAttribute("key");

                if (this.xc.GetNodeChildCount(xn) > 1)
                {
                    Dictionary<string, object> dt = new Dictionary<string, object>();
                    foreach (XmlElement xee in xe.ChildNodes)
                    {
                        dt.Add(xee.GetAttribute("key"), dict_data[xee.GetAttribute("key")]);
                    }
                    dict_data_2[selection] = dt;
                }
                else {
                    Dictionary<string, object> dt = new Dictionary<string, object>();
                    XmlElement xee = (XmlElement)xe.ChildNodes[0];
                    dt.Add(xee.GetAttribute("key"), dict_data[xee.GetAttribute("key")]);
                    dict_data_2[selection] = dt;
                }
            }

            //MessageBox.Show(JsonConvert.SerializeObject(dict_data_2));
            //MessageBox.Show(JsonConvert.SerializeObject(dict_data));

            switch (save_func)
            {
                case "xml":
                    ShowSaveFileDialog(JsonConvert.SerializeObject(dict_data_2), "xml");
                    break;
                case "json":
                    ShowSaveFileDialog(JsonConvert.SerializeObject(dict_data_2), "json");
                    break;
                case "csv":
                    ShowSaveFileDialog(JsonConvert.SerializeObject(dict_data_2), "csv");
                    break;
                case "ini":
                    ShowSaveFileDialog(JsonConvert.SerializeObject(dict_data_2), "ini");
                    break;
                default:
                    MessageBox.Show("未知类型");
                    break;
            }
        }

        public bool strToBool(string message)
        {
            if (message == "true")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool isNumberic(string message, int result=-1)
        {
            Regex rex = new Regex(@"^\d+$");
            if (rex.IsMatch(message))
            {
                result = int.Parse(message);
                return true;
            }
            else
                return false;
        }

        public bool isDouble(string message, double result = -1)
        {
            Regex rex = new Regex(@"^[\d\.]+$");
            if (rex.IsMatch(message))
            {
                result = Convert.ToDouble(message);
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// 显示保存数据对话框
        /// </summary>
        /// <param name="data"></param>
        /// <param name="save_type"></param>
        private void ShowSaveFileDialog(object data, string save_type = "json")
        {
            string write_data = "";
            SaveFileDialog sfd = new SaveFileDialog();

            sfd.Filter = save_type + "|*." + save_type;

            sfd.RestoreDirectory = true;

            sfd.FileName = xc.GetNodeAttByAtt_Name(xc.nodeRoot, "title") + "." + save_type;

            if (sfd.ShowDialog() == true && sfd.FileName.Length > 0)
            {
                if (save_type == "json")
                {
                    write_data = (string)data;
                }
                else if (save_func == "xml")
                {
                    write_data = JsonToXml((string)data);
                }
                else if (save_func == "ini")
                {
                    write_data = XmlToIni(JsonToXml((string)data));
                }
                else if (save_func == "csv")
                {
                    write_data = XmlToCsv(JsonToXml((string)data));
                }
                else
                {
                    return;
                }

                StreamWriter sw;
                try
                {
                    sw = File.CreateText(sfd.FileName);
                }
                catch
                {
                    MessageBox.Show("文件创建失败");
                    return;
                }
                sw.WriteLine(write_data);
                sw.Close();
                MessageBox.Show("保存成功");

            }
            else {
                MessageBox.Show("没有保存");
            }
        }

        public string XmlToCsv(string str_xml)
        {
            string str_csv = "";
            XmlDocument xd = new XmlDocument();
            xd.LoadXml(str_xml);
            foreach (XmlNode xn in xd.SelectNodes("/root/*"))
            {
                string section = xn.Name + ",";
                foreach (XmlNode xnn in xn.SelectNodes("/root/" + xn.Name + "/*"))
                {
                    str_csv += section;
                    string s_key = xnn.Name + ",";
                    string s_value = "";
                    XmlNodeList xnnl = xnn.SelectNodes("/root/" + xn.Name + "/" + xnn.Name + "/*");
                    if (xnnl.Count == 0)
                    {
                        s_value = xnn.InnerText;
                    }
                    else
                    {
                        List<string> li_value = new List<string>();
                        foreach (XmlElement xe in xnnl)
                        {
                            li_value.Add(xe.InnerText);
                        }
                        s_value = string.Join(",", li_value);
                    }
                    s_value += "\n";
                    str_csv += s_key;
                    str_csv += s_value;
                }
            }
            return str_csv;
        }

        public string XmlToIni(string str_xml)
        {
            string str_ini = "";
            XmlDocument xd = new XmlDocument();
            xd.LoadXml(str_xml);
            foreach (XmlNode xn in xd.SelectNodes("/root/*"))
            {
                string section = "[" + xn.Name + "]\n";
                str_ini += section;
                foreach (XmlNode xnn in xn.SelectNodes("/root/"+xn.Name+"/*"))
                {
                    string s_key = xnn.Name + "=\t";
                    string s_value = "";
                    XmlNodeList xnnl = xnn.SelectNodes("/root/" + xn.Name + "/" + xnn.Name + "/*");
                    if (xnnl.Count == 0)
                    {
                        s_value = xnn.InnerText;
                    }
                    else {
                        List<string> li_value = new List<string>();
                        foreach (XmlElement xe in xnnl)
                        {
                            li_value.Add(xe.InnerText);
                        }
                        s_value = "[" + string.Join(",", li_value) + "]";
                    }
                    s_value += "\n";
                    str_ini += s_key;
                    str_ini += s_value;
                }
                str_ini += "\n";
            }
            return str_ini;
        }

        public string JsonToXml(string str_json)
        {
            XmlDictionaryReader reader =
                        JsonReaderWriterFactory.CreateJsonReader(
                            Encoding.UTF8.GetBytes(str_json), XmlDictionaryReaderQuotas.Max
                            );
            XmlDocument doc = new XmlDocument();
            doc.Load(reader);
            return doc.InnerXml;
        }

        /// <summary>
        /// 获取数据
        /// </summary>
        /// <returns></returns>
        public List<List<string>> GetAllDataBeforeSave()
        {
            List<List<string>> data = new List<List<string>>();
            foreach (string ctrl_item in this.ctrl_xname)
            {
                List<string> data_temp = new List<string>();
                string[] str_switch = ctrl_item.Replace("__", "|").Split('|');

                string temp_text =this.xc.GetNodeByPosAttAndValue("key", str_switch[1])
                                    .InnerText.Replace("(", "@").Replace(")", "@");

                switch (str_switch[0])
                {
                    case "tb":
                        data_temp.Add(str_switch[1]);
                        TextBox bt = stackpanel_main.FindName(ctrl_item) as TextBox;
                        data_temp.Add(bt.Text);
                        if (bt.Text == "")
                            return null;
                        break;
                    case "lib_checkbox":
                        data_temp.Add(str_switch[1]);
                        WrapPanel wp = stackpanel_main.FindName(ctrl_item) as WrapPanel;
                        foreach (CheckBox cb in wp.Children)
                        {
                            if (cb.IsChecked == true)
                            {
                                data_temp.Add(
                                    HandleDatsByStr(temp_text, cb.Content.ToString())
                                );
                            }
                        }
                        if (data_temp.Count == 1)
                            return null;
                        break;
                    case "lib_radiobutton":
                        data_temp.Add(str_switch[1]);
                        WrapPanel wp2 = stackpanel_main.FindName(ctrl_item) as WrapPanel;
                        foreach (RadioButton rb in wp2.Children)
                        {
                            if (rb.IsChecked == true)
                            {

                                data_temp.Add(
                                    HandleDatsByStr(temp_text, rb.Content.ToString())
                                );
                                break;
                            }
                        }
                        break;
                    case "cbx":
                        data_temp.Add(str_switch[1]);

                        ComboBox cbx = stackpanel_main.FindName(ctrl_item) as ComboBox;

                        data_temp.Add(
                            HandleDatsByStr(temp_text, cbx.SelectedItem.ToString())
                            );

                        break;
                }
                data.Add(data_temp);
            }
            return data;
        }

        /// <summary>
        /// 数据提取（提取括号中（小括号）的真实数据）
        /// </summary>
        /// <param name="temp_text"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public string HandleDatsByStr(string temp_text, string content)
        {
            string par = string.Format(
                                @"{0}{1}", content, "@.*?@"
                                );
            MatchCollection res = Regex.Matches(
                temp_text, par);
            if (res.Count == 0)
            {
                return content;
            }
            else
            {
                return res[0].Value.Replace("@", "").Replace(content, "");
            }
        }

        /// <summary>
        /// 添加分割线
        /// </summary>
        public void Add_DivLine()
        {
            Line line_div = new Line();
            line_div.Stroke = System.Windows.Media.Brushes.LightSteelBlue;
            line_div.StrokeThickness = 2;
            line_div.X1 = 0;
            line_div.X2 = Convert.ToDouble(xc.GetNodeAttByAtt_Name(xc.nodeRoot, "widht")) - 20;
            line_div.Y1 = 0;
            line_div.Y2 = 0;
            line_div.Margin = new Thickness(10, 10, 10, 10);
            stackpanel_main.Children.Add(line_div);
        }

        /// <summary>
        /// 添加文本框
        /// </summary>
        /// <param name="label_name"></param>
        /// <param name="tb_key"></param>
        public void Add_Text(string label_name, string tb_key)
        {
            TextBox tb = new TextBox(); // 数据来源
            Label lb = new Label();
            StackPanel sp_new = new StackPanel();

            sp_new.Orientation = Orientation.Horizontal;
            sp_new.Margin = new Thickness(10, 15, 0, 0);

            lb.Content = label_name + ":";
            lb.Margin = new Thickness(0, 0, 10, 0);

            tb.Width = 250;
            tb.Height = 20;
            tb.VerticalAlignment = VerticalAlignment.Center;
            tb.HorizontalAlignment = HorizontalAlignment.Center;

            tb.Name = "tb__" + tb_key;
            this.ctrl_xname.Add(tb.Name);
            Stackpanel_main.RegisterName(tb.Name, tb);

            sp_new.Children.Add(lb);
            sp_new.Children.Add(tb);
            Stackpanel_main.Children.Add(sp_new);
        }

        /// <summary>
        /// 添加多选框
        /// </summary>
        /// <param name="label_name"></param>
        /// <param name="cb_content"></param>
        /// <param name="lib_key"></param>
        public void Add_CheckBox(string label_name, string cb_content, string lib_key)
        {
            ListBox lib = new ListBox(); // 数据来源
            Label lb = new Label();
            WrapPanel wp = new WrapPanel();
            StackPanel sp_new = new StackPanel();
            ScrollViewer sv = new ScrollViewer();

            sp_new.Orientation = Orientation.Horizontal;
            sp_new.Margin = new Thickness(10, 15, 0, 0);

            lb.Content = label_name + ":";
            lb.Margin = new Thickness(0, 0, 20, 0);

            wp.Orientation = Orientation.Horizontal;
            wp.Margin = new Thickness(0, 0, 0, 10);

            sv.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            sv.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            sv.IsDeferredScrollingEnabled = true;
            sv.Width = Convert.ToDouble(Xc.GetNodeAttByAtt_Name(Xc.nodeRoot, "widht")) / 5 * 3;

            wp.Name = "lib_checkbox__" + lib_key;
            this.ctrl_xname.Add(wp.Name);
            Stackpanel_main.RegisterName(wp.Name, wp);

            foreach (string str in cb_content.Split('|'))
            {
                CheckBox cb = new CheckBox();

                str.Trim();
                if (str.EndsWith(")") == true)
                {
                    cb.Content = str.Replace("(","|").Replace(")","|").Split('|')[0].Trim();
                }
                else {
                    cb.Content = str;
                }

                cb.IsChecked = false;
                cb.Margin = new Thickness(0, 0, 20, 0);
                cb.Height = 20;
                wp.Children.Add(cb);
            }
            sv.Content = wp;

            lib.Items.Add(sv);
            lib.BorderThickness = new Thickness(1, 1, 1, 1);

            sp_new.Children.Add(lb);
            sp_new.Children.Add(lib);

            Stackpanel_main.Children.Add(sp_new);
        }

        /// <summary>
        /// 添加单选框
        /// </summary>
        /// <param name="label_name"></param>
        /// <param name="rd_content"></param>
        /// <param name="lib_key"></param>
        public void Add_Radio(string label_name, string rd_content, string lib_key)
        {
            bool first_select = false;
            ListBox lib = new ListBox();
            Label lb = new Label();
            WrapPanel wp = new WrapPanel();
            StackPanel sp_new = new StackPanel();
            ScrollViewer sv = new ScrollViewer();

            sp_new.Orientation = Orientation.Horizontal;
            sp_new.Margin = new Thickness(10, 15, 0, 0);

            lb.Content = label_name + ":";
            lb.Margin = new Thickness(0, 0, 20, 0);

            wp.Orientation = Orientation.Horizontal;
            wp.Margin = new Thickness(0, 0, 0, 10);

            sv.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            sv.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            sv.IsDeferredScrollingEnabled = true;
            sv.Width = Convert.ToDouble(Xc.GetNodeAttByAtt_Name(Xc.nodeRoot, "widht")) / 5 * 3;

            wp.Name = "lib_radiobutton__" + lib_key;
            this.ctrl_xname.Add(wp.Name);
            Stackpanel_main.RegisterName(wp.Name, wp);

            foreach (string str in rd_content.Split('|'))
            {
                RadioButton rb = new RadioButton();

                str.Trim();
                if (str.EndsWith(")") == true)
                {
                    rb.Content = str.Replace("(", "|").Replace(")", "|").Split('|')[0].Trim();
                }
                else
                {
                    rb.Content = str;
                }

                rb.Margin = new Thickness(0, 0, 20, 0);
                rb.Height = 20;
                if (first_select == false)
                {
                    rb.IsChecked = true;
                    first_select = true;
                }
                else
                {
                    rb.IsChecked = false;
                }
                wp.Children.Add(rb);
            }
            sv.Content = wp;

            lib.Items.Add(sv);
            lib.BorderThickness = new Thickness(1, 1, 1, 1);

            sp_new.Children.Add(lb);
            sp_new.Children.Add(lib);

            Stackpanel_main.Children.Add(sp_new);
        }

        /// <summary>
        /// 添加下拉选择框
        /// </summary>
        /// <param name="label_name"></param>
        /// <param name="sc_content"></param>
        /// <param name="cbx_key"></param>
        public void Add_Select(string label_name, string sc_content, string cbx_key)
        {
            Label lb = new Label();
            WrapPanel wp = new WrapPanel();
            StackPanel sp_new = new StackPanel();
            ComboBox cbx = new ComboBox();

            lb.Content = label_name + ":";
            lb.Margin = new Thickness(0, 0, 20, 0);

            sp_new.Orientation = Orientation.Horizontal;
            sp_new.Margin = new Thickness(10, 15, 0, 0);

            cbx.Width = 150;
            cbx.SelectedIndex = 0;

            cbx.Name = "cbx__" + cbx_key;
            this.ctrl_xname.Add(cbx.Name);
            Stackpanel_main.RegisterName(cbx.Name, cbx);

            foreach (string str in sc_content.Split('|'))
            {
                str.Trim();
                if (str.EndsWith(")") == true)
                {
                    cbx.Items.Add(str.Replace("(", "|").Replace(")", "|").Split('|')[0].Trim());
                }
                else
                {
                    cbx.Items.Add(str);
                }
            }

            sp_new.Children.Add(lb);
            sp_new.Children.Add(cbx);

            Stackpanel_main.Children.Add(sp_new);
        }
    }
}
